// core/utils/validators.dart
import '../../core/app_constants.dart';

class AuthValidators {
  // Валидатор email с использованием константы из AppConstants
  static String? emailValidator(String? value) {
    if (value == null || value.isEmpty) {
      return AppConstants.emailHint;
    }
    if (!RegExp(AppConstants.emailRegExp).hasMatch(value)) {
      return 'Некорректный формат email';
    }
    return null;
  }

  // Валидатор пароля с проверкой минимальной длины
  static String? passwordValidator(String? value) {
    if (value == null || value.isEmpty) {
      return AppConstants.passwordHint;
    }
    if (value.length < AppConstants.minPasswordLength) {
      return 'Минимум ${AppConstants.minPasswordLength} символов';
    }
    return null;
  }

  // Валидатор для обязательных текстовых полей
  static String? requiredFieldValidator(String? value, String fieldName) {
    if (value == null || value.isEmpty) {
      return 'Поле "$fieldName" обязательно для заполнения';
    }
    return null;
  }

  // Валидатор ссылок для чата
  static String? chatLinkValidator(String? value) {
    if (value == null || value.isEmpty) {
      return 'Введите ссылку для связи';
    }
    try {
      Uri.parse(value);
      return null;
    } catch (e) {
      return 'Некорректный формат ссылки';
    }
  }
}
