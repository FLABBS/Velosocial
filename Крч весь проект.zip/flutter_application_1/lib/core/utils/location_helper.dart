// core/utils/location_helper.dart
import 'package:geolocator/geolocator.dart';

class LocationHelper {
  /// Рассчитывает расстояние между двумя географическими точками в метрах
  /// Использует формулу гаверсинусов для точного расчета на сфере
  static double calculateDistance({
    required double lat1,
    required double lng1,
    required double lat2,
    required double lng2,
  }) {
    return Geolocator.distanceBetween(lat1, lng1, lat2, lng2);
  }

  /// Проверяет, находится ли точка в заданном радиусе (в метрах)
  static bool isWithinRadius({
    required double centerLat,
    required double centerLng,
    required double targetLat,
    required double targetLng,
    required double radiusMeters,
  }) {
    final distance = calculateDistance(
      lat1: centerLat,
      lng1: centerLng,
      lat2: targetLat,
      lng2: targetLng,
    );
    return distance <= radiusMeters;
  }

  /// Конвертирует метры в километры с форматированием
  static String metersToKm(double meters) {
    if (meters < 1000) return '${meters.toStringAsFixed(0)} м';
    return '${(meters / 1000).toStringAsFixed(1)} км';
  }

  /// Форматирует координаты для отображения
  static String formatCoordinates(double lat, double lng) {
    return '${lat.toStringAsFixed(5)}, ${lng.toStringAsFixed(5)}';
  }
}
