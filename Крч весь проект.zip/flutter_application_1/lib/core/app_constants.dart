// core/app_constants.dart
import 'package:flutter/material.dart';

abstract class AppConstants {
  // Основные текстовые константы
  static const String appName = 'Вело-Сообщество';
  static const String defaultErrorMessage = 'Произошла ошибка';
  static const String emailHint = 'Введите email';
  static const String passwordHint = 'Введите пароль';
  static const String signInText = 'Войти';
  static const String signUpText = 'Зарегистрироваться';
  static const String createEventText = 'Создать заезд';
  static const String profileGreeting = 'Привет, велосипедист!';

  // Параметры карты
  static const double mapInitialZoom = 14.0;
  static const double mapUpdateInterval = 10.0; // секунд
  static const int mapRadiusMeters = 5000; // 5 км
  static const double markerAnchor = 0.5;

  // Firebase коллекции
  static const String usersCollection = 'users';
  static const String eventsCollection = 'events';
  static const String locationField = 'location';
  static const String timestampField = 'lastUpdated';

  // Валидация
  static const String emailRegExp =
      r'^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$';
  static const int minPasswordLength = 6;

  // Цвета
  static const Color primaryColor = Color(0xFF00BFA5);
  static const Color mapMarkerColor = Color(0xFF1E88E5);
  static const Color eventMarkerColor = Color(0xFFFFB300);

  // Стили текста
  static const TextStyle titleStyle = TextStyle(
    fontSize: 24,
    fontWeight: FontWeight.w600,
    color: Colors.black87,
  );

  static const TextStyle buttonTextStyle = TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.w500,
    color: Colors.white,
  );

  // Размеры элементов UI
  static const double defaultPadding = 16.0;
  static const double buttonHeight = 48.0;
  static const double avatarRadius = 32.0;
}
