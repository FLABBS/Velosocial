import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'core/app_constants.dart';
import 'data/repositories/auth_repo.dart';
import 'data/repositories/event_repo.dart';
import 'data/repositories/user_repo.dart';
import 'features/auth/auth_bloc.dart';
import 'features/auth/auth_screen.dart';
import 'features/map/map_screen.dart';
import 'features/map/map_cubit.dart';
import 'shared/services/firebase_init.dart';
import 'shared/services/location.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Инициализация Firebase
  final firebaseInitialized = await FirebaseInit.initialize();
  if (!firebaseInitialized) {
    runApp(const FirebaseErrorApp());
    return;
  }

  runApp(
    MultiRepositoryProvider(
      providers: [
        RepositoryProvider(create: (_) => AuthRepository()),
        RepositoryProvider(create: (_) => UserRepository()),
        RepositoryProvider(create: (_) => EventRepository()),
        RepositoryProvider(create: (_) => LocationService()),
      ],
      child: MultiBlocProvider(
        providers: [
          BlocProvider(
            create: (context) => AuthBloc(
              context.read<AuthRepository>(),
            )..add(CheckAuthStatus())
          ),
          BlocProvider(
            create: (context) => MapCubit(
              userRepo: context.read<UserRepository>(),
              eventRepo: context.read<EventRepository>(),
              locationService: context.read<LocationService>(),
            ),
          ),
        ],
        child: const MyApp(),
      ),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConstants.appName,
      theme: _buildTheme(),
      debugShowCheckedModeBanner: false,
      home: BlocBuilder<AuthBloc, AuthState>(
        builder: (context, state) {
          return state is Authenticated ? const MapScreen() : const AuthScreen();
        },
      ),
    );
  }

  ThemeData _buildTheme() {
    return ThemeData(
      primarySwatch: Colors.blue,
      appBarTheme: const AppBarTheme(
        color: Colors.white,
        elevation: 1,
        titleTextStyle: TextStyle(
          color: Colors.black,
          fontSize: 20,
          fontWeight: FontWeight.w600,
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        filled: true,
        fillColor: Colors.grey[50],
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppConstants.primaryColor,
          minimumSize: const Size.fromHeight(AppConstants.buttonHeight),
        ),
      ),
    );
  }
}

class FirebaseErrorApp extends StatelessWidget {
  const FirebaseErrorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline, size: 64, color: Colors.red),
              const SizedBox(height: 20),
              Text(
                'Ошибка инициализации приложения',
                style: TextStyle(
                  fontSize: 20,
                  color: Colors.grey[800],
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                'Проверьте интернет-соединение\nи перезапустите приложение',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey),
              ),
            ],
          ),
        ),
      ),
    );
  }
}