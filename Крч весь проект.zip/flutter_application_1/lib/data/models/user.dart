// data/models/user.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:equatable/equatable.dart';

class User extends Equatable {
  final String id;
  final String email;
  final GeoPoint location;
  final String? name;
  final String? contacts;
  final DateTime lastUpdated;

  const User({
    required this.id,
    required this.email,
    required this.location,
    this.name,
    this.contacts,
    required this.lastUpdated,
  });

  // Конвертация из Firestore документа
  factory User.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return User(
      id: doc.id,
      email: data['email'] ?? '',
      location: data['location'] as GeoPoint,
      name: data['name'],
      contacts: data['contacts'],
      lastUpdated: (data['lastUpdated'] as Timestamp).toDate(),
    );
  }

  // Конвертация в JSON для Firestore

  Map<String, dynamic> toJson() => {
    'id': id,
    'email': email,
    'location': location,
    'name': name,
    'contacts': contacts,
    'lastUpdated': FieldValue.serverTimestamp(),
  };
  // Копирование с изменениями
  User copyWith({
    String? email,
    GeoPoint? location,
    String? name,
    String? contacts,
  }) {
    return User(
      id: id,
      email: email ?? this.email,
      location: location ?? this.location,
      name: name ?? this.name,
      contacts: contacts ?? this.contacts,
      lastUpdated: DateTime.now(),
    );
  }

  @override
  List<Object?> get props => [id, email, location, name, contacts, lastUpdated];
}
