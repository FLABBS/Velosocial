import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:equatable/equatable.dart';

class Event extends Equatable {
  final String id;
  final String title;
  final String? description;
  final GeoPoint location;
  final DateTime date;
  final String chatLink;
  final String creatorId;
  final List<String> participants;
  final DateTime createdAt;

  const Event({
    required this.id,
    required this.title,
    this.description,
    required this.location,
    required this.date,
    required this.chatLink,
    required this.creatorId,
    this.participants = const [],
    required this.createdAt,
  });

  factory Event.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return Event(
      id: doc.id,
      title: data['title'] ?? 'Без названия',
      description: data['description'],
      location: data['location'] as GeoPoint,
      date: (data['date'] as Timestamp).toDate(),
      chatLink: data['chatLink'] ?? '',
      creatorId: data['creatorId'] ?? '',
      participants: List<String>.from(data['participants'] ?? []),
      createdAt: (data['createdAt'] as Timestamp).toDate(),
    );
  }

  Map<String, dynamic> toJson() => {
    'title': title,
    'description': description,
    'location': location,
    'date': Timestamp.fromDate(date),
    'chatLink': chatLink,
    'creatorId': creatorId,
    'participants': participants,
    'createdAt': Timestamp.fromDate(createdAt),
  };

  Event copyWith({
    String? title,
    String? description,
    GeoPoint? location,
    DateTime? date,
    String? chatLink,
    List<String>? participants,
  }) {
    return Event(
      id: id,
      title: title ?? this.title,
      description: description ?? this.description,
      location: location ?? this.location,
      date: date ?? this.date,
      chatLink: chatLink ?? this.chatLink,
      creatorId: creatorId,
      participants: participants ?? this.participants,
      createdAt: createdAt,
    );
  }

  @override
  List<Object?> get props => [
    id,
    title,
    description,
    location,
    date,
    chatLink,
    creatorId,
    participants,
    createdAt,
  ];
}