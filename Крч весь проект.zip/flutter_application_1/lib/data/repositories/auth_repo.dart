// data/repositories/auth_repo.dart
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geolocator/geolocator.dart';

import '../../core/app_constants.dart';
import '../models/user.dart' as app;

class AuthRepository {
  final FirebaseAuth _auth;
  final FirebaseFirestore _firestore;

  AuthRepository({
    FirebaseAuth? auth,
    FirebaseFirestore? firestore,
  })  : _auth = auth ?? FirebaseAuth.instance,
        _firestore = firestore ?? FirebaseFirestore.instance;

  Stream<User?> get authStateChanges => _auth.authStateChanges();

  Future<app.User> signUpWithEmail({
    required String email,
    required String password,
    required String name,
  }) async {
    try {
      final credential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      final user = credential.user;
      if (user == null) throw Exception('Ошибка создания пользователя');

      final position = await _getDefaultLocation();

      final appUser = app.User(
        id: user.uid,
        email: email,
        name: name,
        location: GeoPoint(position.latitude, position.longitude),
        contacts: '',
        lastUpdated: DateTime.now(),
      );

      await _firestore
          .collection(AppConstants.usersCollection)
          .doc(user.uid)
          .set(appUser.toJson());

      return appUser;
    } on FirebaseAuthException catch (e) {
      throw _authExceptionHandler(e);
    } on FirebaseException catch (e) {
      throw Exception('Firestore error: ${e.message}');
    }
  }

  Future<app.User> signInWithEmail({
    required String email,
    required String password,
  }) async {
    try {
      final credential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      final user = credential.user;
      if (user == null) throw Exception('Пользователь не найден');

      final doc = await _firestore
          .collection(AppConstants.usersCollection)
          .doc(user.uid)
          .get();

      if (!doc.exists) throw Exception('Профиль пользователя не найден');
      return app.User.fromFirestore(doc);
    } on FirebaseAuthException catch (e) {
      throw _authExceptionHandler(e);
    }
  }

  Future<void> signOut() async {
    await _auth.signOut();
  }

  Future<app.User?> getCurrentUser() async {
    final user = _auth.currentUser;
    if (user == null) return null;

    final doc = await _firestore
        .collection(AppConstants.usersCollection)
        .doc(user.uid)
        .get();

    return doc.exists ? app.User.fromFirestore(doc) : null;
  }

  Future<void> updateUserProfile(app.User user) async {
    try {
      await _firestore
          .collection(AppConstants.usersCollection)
          .doc(user.id)
          .update(user.toJson());
    } on FirebaseException catch (e) {
      throw Exception('Ошибка обновления: ${e.message}');
    }
  }

  Exception _authExceptionHandler(FirebaseAuthException e) {
    switch (e.code) {
      case 'email-already-in-use':
        return Exception('Email уже зарегистрирован');
      case 'invalid-email':
        return Exception('Некорректный email');
      case 'weak-password':
        return Exception('Пароль слишком простой');
      case 'user-not-found':
        return Exception('Пользователь не найден');
      case 'wrong-password':
        return Exception('Неверный пароль');
      default:
        return Exception(e.message ?? 'Ошибка аутентификации');
    }
  }

  Future<Position> _getDefaultLocation() async {
    try {
      return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.low,
      );
    } catch (_) {
      return Position(
        latitude: 55.7558, // Координаты Москвы
        longitude: 37.6173,
        timestamp: DateTime.now(),
        accuracy: 0.0,
        altitude: 0.0,
        heading: 0.0,
        speed: 0.0,
        speedAccuracy: 0.0,
        altitudeAccuracy: 0.0,
        headingAccuracy: 0.0,
      );
    }
  }
}