import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geolocator/geolocator.dart';

import '../../core/app_constants.dart';
import '../../core/utils/location_helper.dart';
import '../../data/models/event.dart';

class EventRepository {
  final FirebaseFirestore _firestore;

  EventRepository({FirebaseFirestore? firestore})
      : _firestore = firestore ?? FirebaseFirestore.instance;

  /// Получение потока ближайших событий
  Stream<List<Event>> getNearbyEventsStream(Position position) {
    final bounds = _getGeoBounds(
      position.latitude,
      position.longitude,
      AppConstants.mapRadiusMeters.toDouble(), // Конвертация int → double
    );

    return _firestore
        .collection(AppConstants.eventsCollection)
        .where(
      AppConstants.locationField,
      isGreaterThan: bounds['min'],
      isLessThan: bounds['max'],
    )
        .where('date', isGreaterThanOrEqualTo: DateTime.now())
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
          .map((doc) => Event.fromFirestore(doc))
          .where(
            (event) => LocationHelper.isWithinRadius(
          centerLat: position.latitude,
          centerLng: position.longitude,
          targetLat: event.location.latitude,
          targetLng: event.location.longitude,
          radiusMeters: AppConstants.mapRadiusMeters.toDouble(),
        ),
      )
          .toList(),
    );
  }

  /// Создание события
  Future<void> createEvent(Event event) async {
    try {
      await _firestore
          .collection(AppConstants.eventsCollection)
          .add(event.toJson());
    } on FirebaseException catch (e) {
      throw Exception('Ошибка создания: ${e.message}');
    }
  }

  /// Добавление участника
  Future<void> addParticipant(String eventId, String userId) async {
    try {
      await _firestore
          .collection(AppConstants.eventsCollection)
          .doc(eventId)
          .update({
        'participants': FieldValue.arrayUnion([userId]),
      });
    } on FirebaseException catch (e) {
      throw Exception('Ошибка добавления: ${e.message}');
    }
  }

  /// Удаление события
  Future<void> deleteEvent(String eventId) async {
    try {
      await _firestore
          .collection(AppConstants.eventsCollection)
          .doc(eventId)
          .delete();
    } on FirebaseException catch (e) {
      throw Exception('Ошибка удаления: ${e.message}');
    }
  }

  /// Поток обновлений события
  Stream<Event> getEventStream(String eventId) {
    return _firestore
        .collection(AppConstants.eventsCollection)
        .doc(eventId)
        .snapshots()
        .map((doc) => Event.fromFirestore(doc));
  }

  /// Расчет границ для геозапроса
  Map<String, GeoPoint> _getGeoBounds(
      double lat,
      double lng,
      double radiusMeters, // Тип изменен на double
      ) {
    const double distancePerDegree = 111000.0;
    final delta = radiusMeters / distancePerDegree;

    return {
      'min': GeoPoint(lat - delta, lng - delta),
      'max': GeoPoint(lat + delta, lng + delta),
    };
  }
}