// shared/services/location.dart
import 'package:geolocator/geolocator.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';

import '../../core/app_constants.dart';

class LocationService {
  final FirebaseFirestore _firestore;
  final GeolocatorPlatform _geolocator;

  LocationService({
    FirebaseFirestore? firestore,
    GeolocatorPlatform? geolocator,
  })  : _firestore = firestore ?? FirebaseFirestore.instance,
        _geolocator = geolocator ?? GeolocatorPlatform.instance;

  Future<LocationPermission> checkPermissions() async {
    final serviceEnabled = await _geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) throw LocationServiceDisabledException();

    var permission = await _geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await _geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        throw LocationPermissionDeniedException();
      }
    }

    if (permission == LocationPermission.deniedForever) {
      throw LocationPermissionPermanentlyDeniedException();
    }

    return permission;
  }

  Future<Position> getCurrentPosition() async {
    try {
      return await _geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.bestForNavigation,
        ),
      );
    } catch (e) {
      debugPrint('Location error: $e');
      rethrow;
    }
  }

  Future<void> updateUserLocation({
    required String userId,
    required double lat,
    required double lng,
  }) async {
    try {
      await _firestore.collection(AppConstants.usersCollection).doc(userId).update({
        AppConstants.locationField: GeoPoint(lat, lng),
        AppConstants.timestampField: FieldValue.serverTimestamp(),
      });
    } catch (e) {
      debugPrint('Update location error: $e');
      rethrow;
    }
  }

  Stream<Position> get positionStream => _geolocator.getPositionStream(
    locationSettings: const LocationSettings(
      accuracy: LocationAccuracy.bestForNavigation,
      distanceFilter: AppConstants.mapRadiusMeters ~/ 10,
    ),
  ).handleError((e) {
    debugPrint('Position stream error: $e');
    throw e;
  });

  Future<void> enableBackgroundUpdates() async {
    if (kIsWeb) return;

    try {
      final permission = await checkPermissions();

      if (permission != LocationPermission.whileInUse &&
          permission != LocationPermission.always) {
        return;
      }

      var androidSettings = AndroidSettings(
        accuracy: LocationAccuracy.bestForNavigation,
        distanceFilter: AppConstants.mapRadiusMeters ~/ 10,
        foregroundNotificationConfig: const ForegroundNotificationConfig(
          notificationTitle: "Фоновое отслеживание",
          notificationText: "Приложение активно использует геолокацию",
          enableWakeLock: true,
        ),
      );

      _geolocator.getPositionStream(locationSettings: androidSettings)
          .listen((position) {
        debugPrint('Background location: ${position.toString()}');
      });

    } catch (e) {
      debugPrint('Background updates error: $e');
    }
  }
}

class LocationServiceDisabledException implements Exception {
  @override String toString() => 'Включите геолокацию в настройках';
}

class LocationPermissionDeniedException implements Exception {
  @override String toString() => 'Доступ запрещен';
}

class LocationPermissionPermanentlyDeniedException implements Exception {
  @override String toString() => 'Разрешите доступ в настройках телефона';
}