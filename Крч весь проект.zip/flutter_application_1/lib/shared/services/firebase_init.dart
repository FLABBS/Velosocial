import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

class FirebaseInit {
  // Конфигурация Firebase для всех платформ
  static const FirebaseOptions _firebaseOptions = FirebaseOptions(
    apiKey: "AIzaSy...",
    appId: "1:123...",
    messagingSenderId: "123...",
    projectId: "bike-app-mvp",
    storageBucket: "bike-app-mvp.appspot.com",
    // Для веба добавляем обязательные параметры:
    authDomain: "bike-app-mvp.firebaseapp.com",
  );

  /// Инициализация Firebase с универсальной обработкой
  static Future<bool> initialize() async {
    try {
      await Firebase.initializeApp(
        options: kIsWeb ? _firebaseOptions : null,
      );
      debugPrint("Firebase initialized successfully");
      return true;
    } catch (e, stack) {
      debugPrint("""
      Firebase init error: ${e.toString()}
      Stack trace: ${stack.toString()}
      """);
      return false;
    }
  }

  /// Безопасная переинициализация
  static Future<bool> reinitialize() async {
    try {
      await Firebase.app().delete();
      return await initialize();
    } catch (e, stack) {
      debugPrint("""
      Firebase reinit error: ${e.toString()}
      Stack trace: ${stack.toString()}
      """);
      return false;
    }
  }
}