// shared/widgets/event_dialog.dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/app_constants.dart';
import '../../data/models/event.dart';

class EventDialog extends StatefulWidget {
  final Event event;
  final VoidCallback? onJoin;

  const EventDialog({super.key, required this.event, this.onJoin});

  @override
  State<EventDialog> createState() => _EventDialogState();
}

class _EventDialogState extends State<EventDialog> {
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: Text(
        widget.event.title,
        style: AppConstants.titleStyle.copyWith(fontSize: 22),
      ),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (widget.event.description != null) _buildDescription(),
            _buildDetailItem(Icons.calendar_today, _formatDate()),
            _buildDetailItem(Icons.location_pin, _formatCoordinates()),
            _buildDetailItem(Icons.group, _participantsCount()),
            if (widget.event.chatLink.isNotEmpty) _buildChatLink(),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Закрыть'),
        ),
        if (widget.event.chatLink.isNotEmpty)
          ElevatedButton.icon(
            icon: const Icon(Icons.chat, size: 20),
            label: const Text('Присоединиться'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppConstants.primaryColor,
              foregroundColor: Colors.white,
            ),
            onPressed: () async {
              await _launchChatLink();
              if (widget.onJoin != null && mounted) widget.onJoin!();
            },
          ),
      ],
    );
  }

  Widget _buildDescription() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Text(widget.event.description!, style: const TextStyle(fontSize: 16)),
    );
  }

  Widget _buildDetailItem(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 22, color: Colors.grey[700]),
          const SizedBox(width: 12),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 16))),
        ],
      ),
    );
  }

  Widget _buildChatLink() {
    return GestureDetector(
      onTap: _launchChatLink,
      child: Text(
        widget.event.chatLink,
        style: TextStyle(
          color: Colors.blue[700],
          decoration: TextDecoration.underline,
        ),
      ),
    );
  }

  Future<void> _launchChatLink() async {
    if (!mounted) return;

    try {
      final uri = Uri.parse(widget.event.chatLink);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      } else {
        _showError('Не удалось открыть чат');
      }
    } catch (e) {
      _showError('Ошибка: ${e.toString()}');
    }
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red[700],
      ),
    );
  }

  String _formatDate() {
    return DateFormat('dd.MM.yyyy HH:mm').format(widget.event.date);
  }

  String _formatCoordinates() {
    return '${widget.event.location.latitude.toStringAsFixed(5)}, '
        '${widget.event.location.longitude.toStringAsFixed(5)}';
  }

  String _participantsCount() {
    return 'Участников: ${widget.event.participants.length}';
  }
}