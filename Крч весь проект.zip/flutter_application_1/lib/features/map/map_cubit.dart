import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';

import '../../../core/app_constants.dart';
import '../../../data/models/event.dart';
import '../../../data/models/user.dart';
import '../../../data/repositories/event_repo.dart';
import '../../../data/repositories/user_repo.dart';
import '../../../shared/services/location.dart';

part 'map_state.dart';

class MapCubit extends Cubit<MapState> {
  final UserRepository _userRepo;
  final EventRepository _eventRepo;
  final LocationService _locationService;

  late StreamSubscription<Position> _positionSubscription;
  StreamSubscription<List<User>>? _usersSubscription;
  StreamSubscription<List<Event>>? _eventsSubscription;
  StreamSubscription<Event>? _selectedEventSubscription;

  MapCubit({
    required UserRepository userRepo,
    required EventRepository eventRepo,
    required LocationService locationService,
  })  : _userRepo = userRepo,
        _eventRepo = eventRepo,
        _locationService = locationService,
        super(MapInitial()) {
    _init();
  }

  void _init() async {
    await _handleInitialPosition();
    _startLocationTracking();
  }

  Future<void> _handleInitialPosition() async {
    try {
      emit(MapLoading());
      await _locationService.checkPermissions();
      final position = await _locationService.getCurrentPosition();
      final initialLatLng = LatLng(position.latitude, position.longitude);

      _subscribeToUpdates(position);
      emit(
        MapLoaded(
          initialPosition: initialLatLng,
          userMarkers: const {},
          eventMarkers: const {},
        ),
      );
    } catch (e) {
      emit(MapError(message: 'Ошибка инициализации: ${e.toString()}'));
    }
  }

  void _subscribeToUpdates(Position position) {
    _usersSubscription = _userRepo
        .getNearbyUsersStream(
      center: position,
      radius: AppConstants.mapRadiusMeters.toDouble(),
    )
        .listen((users) {
      if (state is MapLoaded) {
        final markers = _createUserMarkers(users);
        emit((state as MapLoaded).copyWith(userMarkers: markers));
      }
    });

    _eventsSubscription = _eventRepo
        .getNearbyEventsStream(position)
        .listen((events) {
      if (state is MapLoaded) {
        final markers = _createEventMarkers(events);
        emit((state as MapLoaded).copyWith(eventMarkers: markers));
      }
    });
  }

  void _startLocationTracking() {
    _positionSubscription = _locationService.positionStream.listen(
          (position) => _updateUserPosition(position),
      onError: (e) => emit(MapError(message: 'Ошибка геолокации: $e')),
    );
  }

  Future<void> _updateUserPosition(Position position) async {
    try {
      await _userRepo.updateUserLocation(
        userId: _userRepo.currentUser?.id ?? '',
        lat: position.latitude,
        lng: position.longitude,
      );

      if (state is MapLoaded) {
        emit(
          (state as MapLoaded).copyWith(
            lastUpdate: DateTime.now(),
            cameraPosition: LatLng(position.latitude, position.longitude),
          ),
        );
      }
    } catch (e) {
      addError(e);
    }
  }

  Set<Marker> _createUserMarkers(List<User> users) {
    return users.map((user) => Marker(
      width: 40,
      height: 40,
      point: LatLng(user.location.latitude, user.location.longitude),
      builder: (ctx) => const Icon(Icons.person_pin, color: Colors.blue),
    )).toSet();
  }

  Set<Marker> _createEventMarkers(List<Event> events) {
    return events.map((event) => Marker(
      width: 40,
      height: 40,
      point: LatLng(event.location.latitude, event.location.longitude),
      builder: (ctx) => const Icon(Icons.location_on, color: Colors.orange),
      anchorPos: AnchorPos.exactly(Anchor(20, 20)),
    )).toSet();
  }

  void selectEvent(String eventId) {
    _selectedEventSubscription?.cancel();
    _selectedEventSubscription = _eventRepo
        .getEventStream(eventId)
        .listen(
          (event) => emit((state as MapLoaded).copyWith(selectedEvent: event)),
      onError: (e) => emit(MapError(message: 'Ошибка загрузки события: $e')),
    );
  }

  Future<void> joinEvent() async {
    if (state is! MapLoaded || (state as MapLoaded).selectedEvent == null) return;

    try {
      final event = (state as MapLoaded).selectedEvent!;
      await _eventRepo.addParticipant(
        event.id,
        _userRepo.currentUser?.id ?? '',
      );
      emit(
        (state as MapLoaded).copyWith(
          selectedEvent: event.copyWith(
            participants: [...event.participants, _userRepo.currentUser?.id ?? ''],
          ),
        ),
      );
    } catch (e) {
      emit(MapError(message: 'Ошибка присоединения: ${e.toString()}'));
    }
  }

  void clearSelection() {
    _selectedEventSubscription?.cancel();
    if (state is MapLoaded) {
      emit((state as MapLoaded).copyWith(selectedEvent: null));
    }
  }

  @override
  Future<void> close() {
    _positionSubscription.cancel();
    _usersSubscription?.cancel();
    _eventsSubscription?.cancel();
    _selectedEventSubscription?.cancel();
    return super.close();
  }
}