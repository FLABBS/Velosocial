part of 'map_cubit.dart';

sealed class MapState extends Equatable {
  const MapState();

  @override
  List<Object?> get props => [];
}

class MapInitial extends MapState {}

class MapLoading extends MapState {}

class MapLoaded extends MapState {
  final LatLng initialPosition;
  final Set<Marker> userMarkers;
  final Set<Marker> eventMarkers;
  final DateTime? lastUpdate;
  final LatLng? cameraPosition;
  final Event? selectedEvent;

  const MapLoaded({
    required this.initialPosition,
    this.userMarkers = const {},
    this.eventMarkers = const {},
    this.lastUpdate,
    this.cameraPosition,
    this.selectedEvent,
  });

  MapLoaded copyWith({
    LatLng? initialPosition,
    Set<Marker>? userMarkers,
    Set<Marker>? eventMarkers,
    DateTime? lastUpdate,
    LatLng? cameraPosition,
    Event? selectedEvent,
  }) {
    return MapLoaded(
      initialPosition: initialPosition ?? this.initialPosition,
      userMarkers: userMarkers ?? this.userMarkers,
      eventMarkers: eventMarkers ?? this.eventMarkers,
      lastUpdate: lastUpdate ?? this.lastUpdate,
      cameraPosition: cameraPosition ?? this.cameraPosition,
      selectedEvent: selectedEvent ?? this.selectedEvent,
    );
  }

  @override
  List<Object?> get props => [
    initialPosition,
    userMarkers,
    eventMarkers,
    lastUpdate,
    cameraPosition,
    selectedEvent,
  ];
}

class MapError extends MapState {
  final String message;

  const MapError({required this.message});

  @override
  List<Object?> get props => [message];
}