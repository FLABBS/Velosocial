// features/map/map_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_map/flutter_map.dart';

import '../../../core/app_constants.dart';
import '../../../data/models/event.dart';
import '../../../shared/widgets/event_dialog.dart';
import 'map_cubit.dart';

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  late final MapController _mapController;
  late final MapCubit _mapCubit;

  @override
  void initState() {
    super.initState();
    _mapController = MapController();
    _mapCubit = context.read<MapCubit>();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppConstants.appName),
        actions: [
          IconButton(
            icon: const Icon(Icons.my_location),
            onPressed: _centerMap,
            tooltip: 'Центрировать карту',
          ),
        ],
      ),
      body: BlocConsumer<MapCubit, MapState>(
        listener: (context, state) {
          if (state is MapLoaded && state.selectedEvent != null) {
            _showEventDialog(context, state.selectedEvent!);
          }
        },
        builder: (context, state) {
          if (state is MapLoaded) {
            return Stack(
              children: [
                FlutterMap(
                  mapController: _mapController,
                  options: MapOptions(
                    center: state.initialPosition,
                    zoom: AppConstants.mapInitialZoom,
                    onTap: (_, __) => _mapCubit.clearSelection(),
                  ),
                  children: [
                    TileLayer(
                      urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                      userAgentPackageName: 'com.velosocial.app',
                    ),
                    MarkerLayer(
                      markers: [
                        ...state.userMarkers,
                        ...state.eventMarkers,
                      ],
                    ),
                  ],
                ),
                _buildUpdateIndicator(state),
              ],
            );
          } else if (state is MapError) {
            return Center(child: Text(state.message));
          }
          return const Center(child: CircularProgressIndicator());
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _navigateToCreateEvent,
        child: const Icon(Icons.add),
      ),
    );
  }

  void _showEventDialog(BuildContext context, Event event) {
    showDialog(
      context: context,
      builder: (context) => EventDialog(event: event),
    ).then((_) => _mapCubit.clearSelection());
  }

  Widget _buildUpdateIndicator(MapLoaded state) {
    return Visibility(
      visible: state.lastUpdate != null &&
          DateTime.now().difference(state.lastUpdate!) < const Duration(seconds: 2),
      child: const Positioned(
        top: 20,
        left: 0,
        right: 0,
        child: LinearProgressIndicator(minHeight: 2),
      ),
    );
  }

  void _centerMap() {
    final state = _mapCubit.state;
    if (state is MapLoaded) {
      _mapController.move(
        state.initialPosition,
        AppConstants.mapInitialZoom,
      );
    }
  }

  void _navigateToCreateEvent() {
    Navigator.pushNamed(context, '/create_event');
  }

  @override
  void dispose() {
    _mapController.dispose();
    super.dispose();
  }
}