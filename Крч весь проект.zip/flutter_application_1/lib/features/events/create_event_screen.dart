// features/events/create_event_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:latlong2/latlong.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../../../core/app_constants.dart';
import '../../../core/utils/validators.dart';
import '../../../data/models/event.dart';
import '../../../data/repositories/event_repo.dart';
import '../../../data/repositories/user_repo.dart';
import '../../../shared/services/location.dart';
import '../map/map_cubit.dart';

class CreateEventScreen extends StatefulWidget {
  const CreateEventScreen({super.key});

  @override
  State<CreateEventScreen> createState() => _CreateEventScreenState();
}

class _CreateEventScreenState extends State<CreateEventScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _chatLinkController = TextEditingController();
  DateTime _selectedDate = DateTime.now().add(const Duration(hours: 1));
  LatLng? _location;
  bool _isLoading = false;

  Future<void> _selectDateTime(BuildContext context) async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime(2100),
    );

    if (pickedDate != null) {
      final TimeOfDay? pickedTime = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.fromDateTime(_selectedDate),
      );

      if (pickedTime != null) {
        setState(() {
          _selectedDate = DateTime(
            pickedDate.year,
            pickedDate.month,
            pickedDate.day,
            pickedTime.hour,
            pickedTime.minute,
          );
        });
      }
    }
  }

  Future<void> _getCurrentLocation() async {
    try {
      final position = await LocationService().getCurrentPosition();
      setState(() {
        _location = LatLng(position.latitude, position.longitude);
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Ошибка получения локации: ${e.toString()}')),
        );
      }
    }
  }

  Future<void> _submitForm() async {
    if (!_formKey.currentState!.validate() || _location == null) return;

    setState(() => _isLoading = true);

    try {
      final userRepo = context.read<UserRepository>();
      final currentUser = userRepo.currentUser;

      final event = Event(
        id: '',
        title: _titleController.text,
        description: _descriptionController.text,
        location: GeoPoint(_location!.latitude, _location!.longitude),
        date: _selectedDate,
        chatLink: _chatLinkController.text,
        creatorId: currentUser?.id ?? '',
        participants: [currentUser?.id ?? ''],
        createdAt: DateTime.now(),
      );

      await context.read<EventRepository>().createEvent(event);
      if (mounted) {
        context.read<MapCubit>().clearSelection();
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Ошибка создания: ${e.toString()}')),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Создать событие'),
        actions: [
          IconButton(
            icon: const Icon(Icons.my_location),
            onPressed: _getCurrentLocation,
            tooltip: 'Использовать текущее местоположение',
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(AppConstants.defaultPadding),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _titleController,
                decoration: const InputDecoration(
                  labelText: 'Название события',
                  prefixIcon: Icon(Icons.title),
                ),
                validator: (value) =>
                    AuthValidators.requiredFieldValidator(value, 'Название'),
              ),
              const SizedBox(height: AppConstants.defaultPadding),
              TextFormField(
                controller: _descriptionController,
                decoration: const InputDecoration(
                  labelText: 'Описание (необязательно)',
                  prefixIcon: Icon(Icons.description),
                ),
                maxLines: 3,
              ),
              const SizedBox(height: AppConstants.defaultPadding),
              ListTile(
                leading: const Icon(Icons.calendar_today),
                title: const Text('Дата и время'),
                subtitle: Text(
                  DateFormat('dd.MM.yyyy HH:mm').format(_selectedDate),
                ),
                onTap: () => _selectDateTime(context),
              ),
              const SizedBox(height: AppConstants.defaultPadding),
              ListTile(
                leading: const Icon(Icons.location_pin),
                title: const Text('Местоположение'),
                subtitle: Text(
                  _location != null
                      ? '${_location!.latitude.toStringAsFixed(5)}, '
                      '${_location!.longitude.toStringAsFixed(5)}'
                      : 'Не выбрано',
                ),
                trailing: IconButton(
                  icon: const Icon(Icons.map),
                  onPressed: () => _navigateToMapSelection(context),
                ),
              ),
              const SizedBox(height: AppConstants.defaultPadding),
              TextFormField(
                controller: _chatLinkController,
                decoration: const InputDecoration(
                  labelText: 'Ссылка на чат',
                  prefixIcon: Icon(Icons.link),
                ),
                validator: AuthValidators.chatLinkValidator,
              ),
              const SizedBox(height: 32),
              ElevatedButton(
                onPressed: _isLoading ? null : _submitForm,
                style: ElevatedButton.styleFrom(
                    backgroundColor: AppConstants.primaryColor,
                    minimumSize: const Size.fromHeight(50)),
                child: _isLoading
                    ? const CircularProgressIndicator()
                    : const Text('Создать событие'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _navigateToMapSelection(BuildContext context) {
    // Реализация выбора места на карте
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _chatLinkController.dispose();
    super.dispose();
  }
}