// features/auth/auth_bloc.dart
import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';
import 'package:bloc/src/bloc.dart';

import '../../../data/repositories/auth_repo.dart';
import '../../data/models/user.dart' as app; // Исправленный импорт модели

part 'auth_event.dart';
part 'auth_state.dart';

class AuthBloc extends Bloc<AuthEvent, AuthState> {
  final AuthRepository _authRepository;
  late final StreamSubscription<app.User?> _userSubscription;

  AuthBloc(this._authRepository) : super(AuthInitial()) {
    on<SignInRequested>(_handleSignIn);
    on<SignUpRequested>(_handleSignUp);
    on<SignOutRequested>(_handleSignOut);
    on<CheckAuthStatus>(_checkAuthStatus);

    _userSubscription = _authRepository.authStateChanges.listen((user) {
      if (user != null) {
        add(CheckAuthStatus());
      } else {
        emit(Unauthenticated());
      }
    }) as StreamSubscription<app.User?>;
  }

  Future<void> _handleSignIn(
      SignInRequested event,
      Emitter<AuthState> emit,
      ) async {
    emit(AuthLoading());
    try {
      final user = await _authRepository.signInWithEmail(
        email: event.email,
        password: event.password,
      );
      if (!isClosed) emit(Authenticated(user: user));
    } catch (e) {
      if (!isClosed) emit(AuthError(e.toString()));
      if (!isClosed) emit(Unauthenticated());
    }
  }

  Future<void> _handleSignUp(
      SignUpRequested event,
      Emitter<AuthState> emit,
      ) async {
    emit(AuthLoading());
    try {
      final user = await _authRepository.signUpWithEmail(
        email: event.email,
        password: event.password,
        name: event.name,
      );
      if (!isClosed) emit(Authenticated(user: user));
    } catch (e) {
      if (!isClosed) emit(AuthError(e.toString()));
      if (!isClosed) emit(Unauthenticated());
    }
  }

  Future<void> _handleSignOut(
      SignOutRequested event,
      Emitter<AuthState> emit,
      ) async {
    try {
      await _authRepository.signOut();
      if (!isClosed) emit(Unauthenticated());
    } catch (e) {
      if (!isClosed) emit(AuthError(e.toString()));
    }
  }

  Future<void> _checkAuthStatus(
      CheckAuthStatus event,
      Emitter<AuthState> emit,
      ) async {
    try {
      final currentUser = await _authRepository.getCurrentUser();
      if (currentUser != null && !isClosed) {
        emit(Authenticated(user: currentUser));
      } else if (!isClosed) {
        emit(Unauthenticated());
      }
    } catch (e) {
      if (!isClosed) emit(AuthError(e.toString()));
      if (!isClosed) emit(Unauthenticated());
    }
  }

  @override
  Future<void> close() {
    _userSubscription.cancel();
    return super.close();
  }
}