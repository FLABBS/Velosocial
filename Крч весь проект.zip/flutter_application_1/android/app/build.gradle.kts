plugins {
    id("com.android.application")
    id("kotlin-android")
    id("dev.flutter.flutter-gradle-plugin")
    id("com.google.gms.google-services") version "4.4.2" apply false
}

android {
    ndkVersion = "27.0.12077973"  // Убрана точка с запятой
    namespace = "com.velosocial.com"
    compileSdk = flutter.compileSdkVersion.toInt()  // Добавлено .toInt()

    // Исправлены кавычки и синтаксис ext.kotlin_version
    ext {
        kotlin_version = "1.9.0"  // Двойные кавычки
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    // Блок buildscript перемещен в конец файла
    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_11.toString()
    }

    defaultConfig {
        applicationId = "com.velosocial.com"
        minSdk = 23
        targetSdk = flutter.targetSdkVersion.toInt()  // Добавлено .toInt()
        versionCode = flutter.versionCode.toInt()     // Добавлено .toInt()
        versionName = flutter.versionName
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("debug")
        }
    }
}

// Блок buildscript перенесен сюда
buildscript {
    dependencies {
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.0")
    }
}

dependencies {
    implementation(platform("com.google.firebase:firebase-bom:33.9.0"))
    implementation("com.google.firebase:firebase-analytics")
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")
}

flutter {
    source = "../.."
}